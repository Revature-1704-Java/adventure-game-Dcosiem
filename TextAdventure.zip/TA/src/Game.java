import java.io.IOException;
import java.util.*;

public class Game {

	static final Scanner scan = new Scanner(System.in);
	
	//The journey always starts in Queen's Landing, so we initialize this room first

	public static void main(String[] args) throws IOException {
		ArrayList<String> c1 = new ArrayList<String>(Arrays.asList("Lowgarden", "Summerfell"));
		ArrayList<String> a1 = new ArrayList<String>(Arrays.asList("Drink", "Fight", "Travel"));
		Room ql = new Room(c1, a1, "Queen's Landing");

		System.out.println(
				"Greetings young traveler, before I can let you travel in Easteros I need to know what to call you.");
		String name = scan.nextLine();
		System.out.println("Ahh, so your name is " + name + ".");        
		Action.startTurn("Queen's Landing", ql);
		scan.close();

	}



}