import java.util.*;

public class Action implements ActionInterface{
	
	 static ArrayList<String> c1 = new ArrayList<String>(Arrays.asList("Lowgarden", "Summerfell"));
     static ArrayList<String> c2 = new ArrayList<String>(Arrays.asList("Queen's Landing", "Summerfell"));
     static ArrayList<String> c3 = new ArrayList<String>(Arrays.asList("Lowgarden", "Queen's Landing"));
	
     static ArrayList<String> a1 = new ArrayList<String>(Arrays.asList("Drink", "Fight", "Travel"));
     static ArrayList<String> a2 = new ArrayList<String>(Arrays.asList("Harvest", "Tour", "Travel"));
     static ArrayList<String> a3 = new ArrayList<String>(Arrays.asList("Hunt", "Practice", "Travel"));

     static Room ql = new Room(c1, a1, "Queen's Landing");
     static Room lg = new Room(c2, a2, "Queen's Landing");
     static Room sf = new Room(c3, a3, "Queen's Landing");
     
     
	
    
    public static void execute(String str, Room r) {
    	System.out.println();
    	System.out.println();
        switch (str){
            case "Drink":
                ActionInterface.drink();
                break;                
            case "Fight":
                ActionInterface.fight();
                break;
            case "Harvest":
                ActionInterface.harvest();
                break;
            case "Tour":
                ActionInterface.tour();           
                break;
            case "Hunt":
                ActionInterface.hunt();
                break;
            case "Practice":
                ActionInterface.practice();  
                break;
            case "Travel":
                r.printGates();
//                Scanner sc = new Scanner(System.in);
                String destination = Game.scan.nextLine();
                Room next_d;                
               
                if(destination.equals("Queen's Landing")){
                	next_d = ql;
                } else if (destination.equals("Summerfell")){
                	next_d = sf;
                } else {
                	next_d = lg;
                }
                //We now start the players turn in the next destination, passing in the previous room so that we can check 
                //that the Room they entered is a valid location from the Room they are currently in
                startTurn(travel(destination, r), next_d);
                break;
            default:
                break;

        }
        System.out.println("You end up back in front of the city.");
        System.out.println("What is it that you would like to do here?");
        r.printContent();
        String action = Game.scan.nextLine();
        Parser.interpret(action, r);
    }
    public static boolean validTravel(String str, Room r){
        ArrayList<String> temp = r.getGate();
        if(temp.contains(str)){
            return true;
        } else {
            return false;
        }
    }
    public static String travel(String s, Room r){        
        if (validTravel(s, r)) {
            return s;
        } else {
        	System.out.println();
        	System.out.println();
            System.out.println("I'm sorry, but you cannot travel to " + s);
            System.out.println("Try again.");
            String new_dest = Game.scan.nextLine();
            travel(new_dest, r);   
            return new_dest;      
        }

    }
    public static void startTurn(String city, Room r) {
    	System.out.println();
    	System.out.println();
    	System.out.println();
        System.out.println("You are now in the city of " + city + ".");
        r.printContent(); 
        System.out.println("What is it that you would like to do here?");
        String action = Game.scan.nextLine();
        Parser.interpret(action, r);
    }
	
}