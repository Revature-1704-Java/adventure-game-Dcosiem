package gameTests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.InputStream;
import java.io.PrintStream;

import org.junit.jupiter.api.Test;

import com.sun.java_cup.internal.runtime.Scanner;

class UserInputValidation {

//	public static int testUserInput(InputStream in,PrintStream out) {
//		Scanner kb = new Scanner(System.out.in);
//		   Scanner keyboard = new Scanner(in);
//		    out.println("Give a number between 1 and 10");
//		    int input = keyboard.nextInt();
//
//		    while (input < 1 || input > 10) {
//		        out.println("Wrong number, try again.");
//		        input = keyboard.nextInt();
//		    }
//
//		    return input;
//		}

}
