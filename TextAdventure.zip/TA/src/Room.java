import java.util.*;
public class Room {
    private ArrayList<String> gates;
    private String location;
    public ArrayList<String> contents;

    public void printLocation (){
        System.out.println("You are in the" + this.location);
    }
    public void printGates(){
        System.out.println("From here you can go to: ");
        for(String g: this.gates){
            System.out.println(g);
        }
    }
    public ArrayList<String> getGate() {
    	return this.gates;
    }
    public ArrayList<String> getContents(){
    	return this.contents;
    }
    public String getLocation() {
    	return this.location;
    }
    public void printContent(){
        System.out.println("Here are a list of things you can do here: ");
        for(String c: this.contents){
            System.out.println(c);
        }    
    }

    public Room(ArrayList<String> gates, ArrayList<String> contents, String loc){
        this.gates = gates;
        this.contents = contents;
        this.location = loc;
    }

    public Room(){
    }
    

}