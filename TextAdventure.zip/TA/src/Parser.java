import java.util.*;
 
public class Parser{
	

    public static boolean validAction(String str, Room r){
        ArrayList<String> temp = r.getContents();
        if(temp.contains(str)){
            return true;
        } else {
            return false;
        }
    }
    
    //take action user inputs and read description for that action from that location
    public static void interpret(String action, Room r) {   

        if(validAction(action, r)){
            Action.execute(action, r);
        } else {
            System.out.println("I'm sorry, but you cannot " + action + " here.");
            System.out.println("Try again.");
            String new_action = Game.scan.nextLine();
            interpret(new_action, r);           
        }

    }
}