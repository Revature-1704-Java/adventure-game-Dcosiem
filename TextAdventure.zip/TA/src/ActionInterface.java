
public interface ActionInterface {
	public static void drink() {
		System.out.println("You go to a tavern nearby and start a tab.");
        System.out.println("After having one too many drinks you decide to pick a fight with the barkeep.");
        System.out.println("You blackout and have no recollection of what just happened.");
	}
	public static void fight(){
		System.out.println("A hooded figure brushes past you and you bump shoulders.");
        System.out.println("You take this as an act of war and fight this person to the death.");
        System.out.println("You unsheath your sword and quickly slay them.");
        System.out.println("It turns out you killed the Queen's child.");
        System.out.println("Word of this reaches the Queen and you are executed.");
        System.out.println("Game Over!");
        System.exit(0);
	}
	public static void harvest() {
		System.out.println("You pick some grapes in the gardens and bring them to the winery to make wine.");
        System.out.println("You drink two bottles and pass out.");
	}
	public static void hunt() {
		System.out.println("The men in the city are about to go on a hunt and invite you to come along.");
        System.out.println("You nod your head and they give you a dagger, you follow them into the woods.");
        System.out.println("After several hours you return with the group carrying a wild hog with another hunter.");
	}
	public static void practice() {
		System.out.println("As you enter the town you see someone land a bullseye on a target.");
        System.out.println("A strangers voice beckons to you.");
        System.out.println("He askes, \"do you want to try?\"");
        System.out.println("You say you'll be able to do better than him after a few rounds.");
        System.out.println("You are proven wrong and you leave hearing him chant");
        System.out.println("Shame!");
        System.out.println("Shame!");
        System.out.println("Shame!");
        System.out.println("Shame!");
	}
	public static void tour() {
		System.out.println("You take a tour with one of the locals.");
        System.out.println("You remark how beautiful the Lowgardens are.");     
	}


}
